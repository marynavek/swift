import UIKit
/*
enum type : String {
    case consultant = "finance consultant"
    case educator = "educator"
    case personalTrainer = "personal trainer"
    case developer = "sodtware developer"
}
enum fixedSalary : Float {
    case consultant = 50.0
    case educator = 45.0
    case personalTrainer = 65.0
    case developer = 70.0
}
*/
struct Consultant{
    var type : String = "finance consultant"
    var yearsOfExperince : Float = 0.0
    var fixedSalary : Float = 50.0
    var totalSalary : Float = 0.0
    mutating func total(type: String, yearsOfExperience : Float, fixedSalary : Float) -> (totalSalary : Float, Explanation : String) {
    var salary : Float = 0
    var info : String = ""
    salary = (yearsOfExperience * (0.1) + 1) * fixedSalary
    info = "This \(type) charges \(String(salary)) per hour based on the experience"
    return (salary, info)
    }
}
struct Educator{
    var type : String = "educator"
    var yearsOfExperince : Float = 0.0
    var fixedSalary : Float = 45.0
    var totalSalary : Float = 0.0
    mutating func total(type: String, yearsOfExperience : Float, fixedSalary : Float) -> (totalSalary : Float, Explanation : String) {
    var salary : Float = 0
    var info : String = ""
    salary = (yearsOfExperience * (0.1) + 1) * fixedSalary
    info = "This \(type) charges \(String(salary)) per hour based on the experience"
    return (salary, info)
    }
}
struct Developer{
    var type : String = "software developer"
    var yearsOfExperince : Float = 0.0
    var fixedSalary : Float = 65.0
    var totalSalary : Float = 0.0
    mutating func total(type: String, yearsOfExperience : Float, fixedSalary : Float) -> (totalSalary : Float, Explanation : String) {
    var salary : Float = 0
    var info : String = ""
    salary = (yearsOfExperience * (0.1) + 1) * fixedSalary
    info = "This \(type) charges \(String(salary)) per hour based on the experience"
    return (salary, info)
    }
}

struct PersonalTrainer{
    var type : String = "personal trainer"
    var yearsOfExperince : Float = 0.0
    var fixedSalary : Float = 80.0
    var totalSalary : Float = 0.0
    mutating func total(type: String, yearsOfExperience : Float, fixedSalary : Float) -> (totalSalary : Float, Explanation : String) {
        var salary : Float = 0.0
        var info : String = ""
        salary = (yearsOfExperience * (0.1) + 1) * fixedSalary
        info = "This \(type) charges \(String(salary)) per hour based on the experience"
        return (salary, info)
    }
}

/*
enum AccountInfo : String {
    case success = "Transaction was succesfull"
    case failure = "You do not have enough balance to pay"
}
*/

class BuyerAccount {
    var name : String = " "
    var balance : Float = 0.0
    var hours : Float = 0.0
    func due(hoursToWork : Float, charge : Float) -> (totalDue :Float, Explanation : String ){
        var toPay : Float = 0.0
        var payInfo : String = ""
        toPay = hoursToWork * charge
        payInfo = "Based on the \(hoursToWork) hours that you chose and workers experiece your total due is \(String(toPay))"
        return(toPay, payInfo)
    }
    
    func Payment (totalDue : Float) -> (currentBalance: Float, TransactionInfo : String){
        var tInfo : String = ""
        if totalDue <= balance {
            balance = balance - totalDue
            tInfo = "Transaction was successful.Your current balance = \(balance)"
            return (balance, tInfo)
        }
        else {
            tInfo = "You do not have enough money on your balance. Your current balance = \(balance)"
        return (balance, tInfo)
        }
    }
}

//client hires financial conusltants for 2 hours
var worker = Consultant()
worker.yearsOfExperince = 1.5
let workerInfo = worker.total(type: worker.type, yearsOfExperience: worker.yearsOfExperince, fixedSalary: worker.fixedSalary)
let client = BuyerAccount()
client.balance = 200.0
print(workerInfo.Explanation)
let totalDue = client.due(hoursToWork: 2, charge: workerInfo.totalSalary)
print (totalDue.Explanation)
let payment = client.Payment(totalDue: totalDue.totalDue)
print(payment.TransactionInfo)

//client hires software developer for 4 hours
var worker1 = Developer()
worker1.yearsOfExperince = 3.0
let worker1Info = worker1.total(type: worker1.type, yearsOfExperience: worker1.yearsOfExperince, fixedSalary: worker1.fixedSalary)
let client1 = BuyerAccount()
client1.balance = 350.0
print(worker1Info.Explanation)
let totalDue1 = client1.due(hoursToWork: 4, charge: worker1Info.totalSalary)
print (totalDue1.Explanation)
let payment1 = client1.Payment(totalDue: totalDue1.totalDue)
print(payment1.TransactionInfo)

//client hires software developer for 4 hours
var worker2 = PersonalTrainer()
worker2.yearsOfExperince = 1.5
let worker2Info = worker2.total(type: worker2.type, yearsOfExperience: worker2.yearsOfExperince, fixedSalary: worker2.fixedSalary)
let client2 = BuyerAccount()
client2.balance = 250.0
print(worker2Info.Explanation)
let totalDue2 = client2.due(hoursToWork: 3, charge: worker2Info.totalSalary)
print (totalDue2.Explanation)
let payment2 = client2.Payment(totalDue: totalDue2.totalDue)
print(payment2.TransactionInfo)

